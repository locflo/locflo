document.addEventListener('DOMContentLoaded', function() {
    createGrid();
});

function createGrid() {
    const tbody = document.querySelector('#sudoku-board tbody');
    tbody.innerHTML = '';

    for (let i = 0; i < 9; i++) {
        const row = document.createElement('tr');
        for (let j = 0; j < 9; j++) {
            const cell = document.createElement('td');
            const input = document.createElement('input');
            input.type = 'number';
            input.min = '1';
            input.max = '9';
            input.dataset.row = i;
            input.dataset.col = j;

            // Add input validation
            input.addEventListener('input', function(e) {
                const value = e.target.value;
                if (value && (value < 1 || value > 9)) {
                    e.target.value = '';
                }
                // Remove solved class when user edits the value
                e.target.classList.remove('solved');
            });

            cell.appendChild(input);
            row.appendChild(cell);
        }
        tbody.appendChild(row);
    }
}

function getGridValues() {
    const grid = [];
    for (let i = 0; i < 9; i++) {
        const row = [];
        for (let j = 0; j < 9; j++) {
            const input = document.querySelector(`input[data-row="${i}"][data-col="${j}"]`);
            row.push(parseInt(input.value) || 0);
        }
        grid.push(row);
    }
    return grid;
}

function setGridValues(grid) {
    // Store original values to mark them differently
    const originalGrid = getGridValues();

    for (let i = 0; i < 9; i++) {
        for (let j = 0; j < 9; j++) {
            const input = document.querySelector(`input[data-row="${i}"][data-col="${j}"]`);
            const newValue = grid[i][j];
            input.value = newValue || '';

            // Mark solved cells with a different style
            if (newValue && !originalGrid[i][j]) {
                input.classList.add('solved');
            }
        }
    }
}

function showMessage(message, isError = false) {
    const messageEl = document.getElementById('message');
    messageEl.textContent = message;
    messageEl.classList.remove('d-none', 'alert-success', 'alert-danger');
    messageEl.classList.add(isError ? 'alert-danger' : 'alert-success');
}

function clearGrid() {
    const inputs = document.querySelectorAll('#sudoku-board input');
    inputs.forEach(input => {
        input.value = '';
        input.classList.remove('solved');
    });
    const messageEl = document.getElementById('message');
    messageEl.classList.add('d-none');
}

async function solveSudoku() {
    const grid = getGridValues();

    try {
        const response = await fetch('/solve', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ grid })
        });

        const data = await response.json();

        if (response.ok) {
            setGridValues(data.solution);
            showMessage('Sudoku solved successfully!');
        } else {
            showMessage(data.error, true);
        }
    } catch (error) {
        showMessage('An error occurred while solving the puzzle.', true);
    }
}