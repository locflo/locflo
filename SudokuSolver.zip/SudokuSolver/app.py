import os
from flask import Flask, render_template, request, jsonify
from sudoku_solver import solve_sudoku, is_valid_sudoku

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default-secret-key")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/solve', methods=['POST'])
def solve():
    try:
        # Get the grid data from the request
        grid = request.json['grid']
        
        # Validate input
        if not is_valid_sudoku(grid):
            return jsonify({'error': 'Invalid Sudoku puzzle'}), 400
        
        # Solve the puzzle
        solution = solve_sudoku(grid)
        
        if solution:
            return jsonify({'solution': solution})
        else:
            return jsonify({'error': 'No solution exists'}), 400
            
    except Exception as e:
        return jsonify({'error': str(e)}), 400
