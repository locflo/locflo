def is_valid_move(grid, row, col, num):
    # Check row
    for x in range(9):
        if grid[row][x] == num:
            return False

    # Check column
    for x in range(9):
        if grid[x][col] == num:
            return False

    # Check 3x3 box
    start_row = row - row % 3
    start_col = col - col % 3
    for i in range(3):
        for j in range(3):
            if grid[i + start_row][j + start_col] == num:
                return False

    return True

def find_empty_location(grid):
    for i in range(9):
        for j in range(9):
            if grid[i][j] == 0:
                return i, j
    return None

def solve_sudoku(grid):
    # Make a copy of the grid to avoid modifying the original
    grid = [row[:] for row in grid]

    # Find an empty cell
    empty = find_empty_location(grid)

    # If there are no empty cells, the puzzle is solved
    if not empty:
        return grid

    row, col = empty

    # Try digits 1-9 in the empty cell
    for num in range(1, 10):
        if is_valid_move(grid, row, col, num):
            # Place the number if it's valid
            grid[row][col] = num

            # Recursively try to solve the rest of the puzzle
            result = solve_sudoku(grid)
            if result:
                return result

            # If placing the number didn't lead to a solution,
            # backtrack by setting it back to 0
            grid[row][col] = 0

    # If no number can be placed, return None
    return None

def is_valid_sudoku(grid):
    # Check if input is valid
    if not isinstance(grid, list) or len(grid) != 9:
        return False

    for row in grid:
        if not isinstance(row, list) or len(row) != 9:
            return False
        for num in row:
            if not isinstance(num, int) or num < 0 or num > 9:
                return False

    # Check rows, columns and boxes
    for i in range(9):
        row = set()
        col = set()
        box = set()

        for j in range(9):
            # Check row
            if grid[i][j] != 0:
                if grid[i][j] in row:
                    return False
                row.add(grid[i][j])

            # Check column
            if grid[j][i] != 0:
                if grid[j][i] in col:
                    return False
                col.add(grid[j][i])

            # Check 3x3 box
            box_row = 3 * (i // 3) + j // 3
            box_col = 3 * (i % 3) + j % 3
            if grid[box_row][box_col] != 0:
                if grid[box_row][box_col] in box:
                    return False
                box.add(grid[box_row][box_col])

    return True